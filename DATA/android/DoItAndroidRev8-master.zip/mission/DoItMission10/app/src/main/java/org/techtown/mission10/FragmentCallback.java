package org.techtown.mission10;

import android.os.Bundle;

public interface FragmentCallback {

    public void onFragmentSelected(int position, Bundle bundle);

}
